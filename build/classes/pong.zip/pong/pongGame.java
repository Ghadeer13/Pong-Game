
package pong;

public class pongGame {
    public static void main (String []args){
    
       GameFrame frame = new GameFrame();
    
    
    }
}
