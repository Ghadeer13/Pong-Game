
package pong;


public class Pong {

 
    public static void main(String[] args) {
       GameFrame frame = new GameFrame();
    }
    
}
